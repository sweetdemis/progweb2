const express = require("express")
const mongoose = require("mongoose")
const passport = require("passport")
const LocalStrategy = require("passport-local")
const expressSession = require("express-session")
const User = require("./models/user")

const app = express()

app.set("view engine", "ejs")

app.use(express.urlencoded({extend: true}))

app.use(expressSession({
    secret: "secret",
    resave: false, 
    saveUninitialized: false
}))

app.use(passport.initialize())
app.use(passport.session())
passport.use(new LocalStrategy(User.authenticate()))
passport.serializeUser(User.serializeUser())
passport.deserializeUser(User.deserializeUser())

mongoose.connect("mongodb://127.0.0.1/autenticacao")
    .then(() => {
        console.log("conexão estabelecida")
    })
    .catch(err => {
        console.log("erro ao conectar")
        console.log(err)
    })

app.get("/", (req, res) => {
    res.render("home")
})

app.get("/register", (req, res) => {
    res.render("register")
})

app.post("/register", (req, res) => {
    User.register(new User({username: req.body.username}), req.body.password, () => {
        if(err) {
            console.log(err)
            res.render("/register")
        } else {
            passport.authenticate("local")(req, res, () => {
                res.redirect("/secret")
            })
        }
    }) 
})

const isLoggedIn = (req, res, next) => {
    if(req ,isAuthenticated()) {
        return next()
    }
    res.redirect("/login")
}

app.get("/secret", (req,res) => {
    res.render("/secret")
})

app.listen(3000, () => {
    console.log("servidor ligado na porta 3000")
})