const Animal = require("./models/animal")

const animal1 = new Animal({
    especie: 'Gato',
    idade: '12',
    porte: 'pequeno'
})

const animal2 = new Animal({
    especie: 'Cachorro',
    idade: '7',
    porte: 'grande'
})

const animal3 = new Animal({
    especie: 'Pato',
    idade: '3',
    porte: 'pequeno'
})

Animal.insertMany([animal1, animal2, animal3])
    .then(res => console.log(res))
    .catch(e => console.log(e))

// animal1.save()
// .then(animal => console.log("animal gravado com sucesso: ",animal))
// .catch(e => console.log(e))

// animal2.save()
// .then(animal => console.log("animal gravado com sucesso: ",animal))
// .catch(e => console.log(e))

// animal3.save()
// .then(animal => console.log("animal gravado com sucesso: ",animal))
// .catch(e => console.log(e))