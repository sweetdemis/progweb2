const mongoose = require('mongoose')

const animalSchema = new mongoose.Schema({
    especie: {
        type: String,
        required: true
        },
    idade: Number,
    porte: String
})

const Animal = mongoose.model("Animal", animalSchema) //cria e lê

module.exports = Animal