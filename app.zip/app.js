const express = require("express");
const app = express();
const methodOverride = require("method-override");
const Animal = require("./models/animal")

app.set("view engine", "ejs");

app.use(express.urlencoded({extended: true}));
app.use(methodOverride('_method'));



app.get("/", (req, res) => {
    res.redirect("/animais");
});

app.get("/animais", async (req, res) => {
    const animais = await Animal.find({}) //a {} vazia busca todos os resultados (especie: "Gato")
    res.render("index", {animais});
});

app.get("/animais/new", (req, res) => {
    res.render("new");
});

app.post("/animais", async (req, res) => {
    const {especie, idade, porte} = req.body;
    const novoAnimal = new Animal ({especie, idade, porte})
    await novoAnimal.save()
    res.redirect("/animais")
});

app.get("/animais/:id", async (req, res) => {
    const {id} = req.params
    const animal = await Animal.findById(id)
    res.render("show", {animal});
});

app.get("/animais/:id/edit", async (req, res) => {
    const {id} = req.params;
    const animal = await Animal.findById(id);
    res.render("edit", {animal});
});

app.patch("/animais/:id", async (req, res) => {
    const {id} = req.params;
    await Animal.findByIdAndUpdate(id, req.body, {runValidators: true})
    res.redirect("/animais/" + id);
})

app.delete("/animais/:id", async (req, res) => {
    const {id} = req.params
    await Animal.findByIdAndDelete(id)
    res.redirect("/animais");
});

app.listen(3000, () => {
    console.log("Server ligado na porta 3000.")
});