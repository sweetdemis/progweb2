const mongoose = require('mongoose')

mongoose.connect('mongodb://127.0.0.1:27017/dbAnimais')
.then(() => {
    console.log("Conexão estabelecida com o banco")
})

.catch( err => {
    console.log("Erro ao conectar no banco")
    console.log(err)
})

module.exports = mongoose