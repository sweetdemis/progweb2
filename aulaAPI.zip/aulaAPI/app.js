const express = require("express")
const request = require("request")
const app = express()
const path = require("path")
const { response } = require("express")

app.set("view engine", "ejs")
app.set("views", path.join(__dirname, "views"))

app.use(express.static(path.join(__dirname, "public")))

// request("https://www.googleapis.com/books/v1/volumes?q=intitle::pride", (error, response, body) => {
//     if (!error && response.statusCode == 200) {
//         const resposta = JSON.parse(body)
//         console.log(resposta.items[0].volumeInfo.title)
//     } 
// });

app.get("/", (req, res) => {
    res.render('busca')
})

app.get("/busca", (req, res) => {
    let {busca, titulo} = req.query
        request("https://www.googleapis.com/books/v1/volumes?q="+tipo + busca, (error, response, body) => {
        if (!error && response.statusCode == 200) {
            const resposta = JSON.parse(body)
            res.render('resultadoBusca', {resposta})
        } 
    })
})

app.listen(3000, () => {
    console.log("servidor ligado na porta 3000")
})