const connection = require('./db.js')

connection.connect((err) => {
    if(err) {
        console.log(err)
    } else {
        console.log("conectado ao banco")
    }
})

let sql = 'CREATE TABLE IF NOT EXISTS aniamais (_id int AUTO_INCREMENT, nome varchar(100), email varchar(70), cpf varchar(11), PRIMARY KEY(_id))'