const express = require("express");
const app = express();
const methodOverride = require("method-override");
const connection = require('./db.js')

app.set("view engine", "ejs");
app.use(express.urlencoded({extended: true}));
app.use(methodOverride('_method'));

connection.connect((err) => {
    if (err) {
        console.log(err)
    } else {
        console.log("conectado ao banco")
    }
})

app.get("/", (req, res) => {
    res.redirect("/pessoas")
})

app.get("/pessoas", (req, res) => {
    const sql = 'SELECT * FROM pessoas'
    connection.query(sql, (err, pessoas) => {
        if (err) {
            console.log(err)
        } else {
            res.render('index', {pessoas})
        }
    })
})